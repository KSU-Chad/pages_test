@echo off
cd /d C:\Public\RAS212\jazzy-lab
docker compose up --build
pause
