---
title: "Set Up the RAS 212 Simulation Environment at Home"
date: 2026-09-17 09:00:00 -0600
categories: [Getting Started, At-Home Setup]
tags: [docker, ros2, setup]
pin: true
---

Want to keep working on labs outside of class, or just prefer testing your
code on your own machine? This is the same environment used on the lab
computers, packaged so you can run it at home — on Windows, with Docker.

**Note:** unlike the lab computers, your home machine won't reset itself
between sessions — so once this is set up, you generally only need to
rebuild it after you update the files, not every single time you use it.

## 1. Download the environment files

[Download ras212-jazzy-lab-home.zip](/downloads/ras212-jazzy-lab-home.zip)

Unzip it somewhere on your computer — anywhere works (Documents, Desktop,
wherever you'll remember). Inside you'll find:

```
jazzy-lab/
├── Dockerfile
├── docker-compose.yml
├── README.md
└── supervisor/
    └── supervisord.conf
```

## 2. Install Docker Desktop

If you don't already have it:

1. Download Docker Desktop from [docker.com](https://www.docker.com/products/docker-desktop/) — get the **AMD64** version
   (this is correct even on Intel CPUs — "AMD64" is just the generic name for
   64-bit PCs, not AMD-specific). Check under Windows Settings → System →
   About → "System type" if you're not sure.
2. During install, make sure the **WSL2 backend** is selected (should be the default).
3. If Docker Desktop asks to enable WSL2 as part of setup, allow it — this is
   a required piece, not optional, for running Linux containers on Windows.
4. Once installed, open Docker Desktop and skip signing in if asked — you
   don't need a Docker account for this.

## 3. Allocate resources

Docker Desktop → Settings → Resources → Advanced. Give it at least
**4 CPUs / 8GB RAM** if your machine has it to spare — this environment runs
Gazebo without a dedicated GPU, so it leans more on CPU than usual.

## 4. Build and start it

Open Command Prompt, navigate to wherever you unzipped the folder, for example:

```
cd C:\Users\yourname\Documents\jazzy-lab

```

Then:

```
docker compose up --build
```

First build takes a while (multi-GB base image) — grab a coffee. Leave this
window open (minimized is fine) while you work.

## 5. Open it in your browser

Once the text settles down and stops scrolling, go to:

```
http://localhost:6080
```

Log in with:

- **Username:** `student`
- **Password:** `student`

You'll land on a full desktop with VS Code, a terminal, Firefox, and Gazebo
all ready to go — the same environment used in the lab.

## Next time you want to use it

Since your home computer doesn't reset itself, you don't need `--build`
every time — plain:

```
docker compose up
```

starts it fast from what's already built. You'll only need `--build` again
if you download an updated version of these files later in the semester.

**When you're done:** stopping the Command Prompt window doesn't fully shut
things down — use Docker Desktop's **Containers** tab and click **Stop** on
`jazzy-lab` when you're finished for the day.

## Saving your work

Anything you save inside the `ros2_ws/src` folder (visible in VS Code's file
explorer on the left) automatically appears in a `student-workspace` folder
next to your unzipped project files on your actual computer — that's how
your code survives between sessions. Save your actual lab work there, not
just anywhere on the desktop inside the environment.
